package WorldModel;
/**
 * Just a wrap for a pair of values.
 * @author Jaime
 *
 */
public class Pair {
	int x; int y;
	Pair(int ix, int iy){
		this.x=ix; this.y=iy;
	}
	public int getX(){return x;}
	public int getY(){return y;}
}
